<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('bookings', function (Blueprint $table) {
        $table->id('id_booking');
        $table->string('nama_pasien', 100);
        $table->string('no_hp', 20);
        $table->string('layanan', 100);
        $table->string('dokter', 100);
        $table->date('tgl_reservasi');
        $table->string('shift_jam', 50);
        $table->enum('status_booking', ['Booking Masuk', 'Terkonfirmasi', 'Sedang Ditangani', 'Selesai', 'Batal'])->default('Booking Masuk');
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
