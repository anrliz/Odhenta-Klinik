<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
use App\Http\Controllers\BookingController;

Route::post('/booking/store', [BookingController::class, 'store'])->name('booking.store');