<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama'    => 'required|string|max:100',
            'nohp'    => 'required|string|max:20',
            'layanan' => 'required|string|max:100',
            'dokter'  => 'required|string|max:100',
            'tanggal' => 'required|date',
            'jam'     => 'required|string|max:50',
        ]);

        $booking = Booking::create([
            'nama_pasien'   => $validated['nama'],
            'no_hp'         => $validated['nohp'],
            'layanan'       => $validated['layanan'],
            'dokter'        => $validated['dokter'],
            'tgl_reservasi' => $validated['tanggal'],
            'shift_jam'     => $validated['jam'],
            'status_booking'=> 'Booking Masuk',
        ]);

        return response()->json([
            'status'  => 'success',
            'message' => 'Data booking berhasil disimpan!',
            'data'    => $booking
        ]);
    }
}