<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    protected $primaryKey = 'id_booking';

    protected $fillable = [
        'nama_pasien',
        'no_hp',
        'layanan',
        'dokter',
        'tgl_reservasi',
        'shift_jam',
        'status_booking',
    ];
}