document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // Ambil nilai dari input form
  const nama = document.getElementById('nama').value;
  const nohp = document.getElementById('nohp').value;
  const layanan = document.getElementById('layanan-select').value;
  const dokter = document.getElementById('dokter-select').value;
  const tanggal = document.getElementById('tanggal').value;
  const jam = document.getElementById('jam').value;

  // Siapkan data untuk dikirim ke backend Laravel
  const formData = new FormData();
  formData.append('nama', nama);
  formData.append('nohp', nohp);
  formData.append('layanan', layanan);
  formData.append('dokter', dokter);
  formData.append('tanggal', tanggal);
  formData.append('jam', jam);

  // Ambil token CSRF dari tag meta
  const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

  // Kirim data ke endpoint Laravel via AJAX (Fetch API)
  fetch('/booking/store', {
    method: 'POST',
    headers: {
      'X-CSRF-TOKEN': token
    },
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.status === 'success') {
      // Jika berhasil simpan ke database MySQL, buka WhatsApp
      const targetPhone = "6282259824496"; 
      
      const message = `Halo ODHENTA SMART / CLINIC,\n` +
                      `Saya ingin melakukan booking jadwal konsultasi/perawatan:\n\n` +
                      `👤 *Nama Pasien:* ${nama}\n` +
                      `📱 *No. HP/WA:* ${nohp}\n` +
                      `🦷 *Layanan:* ${layanan}\n` +
                      `👨‍⚕️ *Dokter:* ${dokter}\n` +
                      `📅 *Tanggal:* ${tanggal}\n` +
                      `⏰ *Shift/Jam:* ${jam}\n\n` +
                      `Mohon konfirmasi ketersediaan jadwal. Terima kasih!`;

      const encodedMessage = encodeURIComponent(message);
      const whatsappURL = `https://wa.me/${targetPhone}?text=${encodedMessage}`;

      window.open(whatsappURL, '_blank');
      document.getElementById('bookingForm').reset();
    } else {
      alert("Gagal menyimpan booking. Silakan periksa kembali data Anda.");
    }
  })
  .catch(error => {
    console.error('Error:', error);
    alert("Terjadi kesalahan sistem saat menghubungi server.");
  });
});