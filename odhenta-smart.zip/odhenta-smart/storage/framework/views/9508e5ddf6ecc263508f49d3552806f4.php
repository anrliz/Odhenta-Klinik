<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Booking Klinik Odhenta Smart</title>
    <style>
        body { font-family: sans-serif; background-color: #f4f7f6; padding: 20px; }
        .form-container { max-width: 500px; margin: auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
        button:hover { background: #218838; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Formulir Booking Odhenta Smart</h2>
    <form id="bookingForm">
        <div class="form-group">
            <label>Nama Pasien</label>
            <input type="text" id="nama" required placeholder="Masukkan nama lengkap">
        </div>
        <div class="form-group">
            <label>No. HP / WA</label>
            <input type="text" id="nohp" required placeholder="Contoh: 081234567890">
        </div>
        <div class="form-group">
            <label>Pilih Layanan</label>
            <select id="layanan-select" required>
                <option value="">-- Pilih Layanan --</option>
                <option value="Konsultasi">Konsultasi</option>
                <option value="Pembersihan Karang Gigi">Pembersihan Karang Gigi</option>
                <option value="Penambalan Gigi">Penambalan Gigi</option>
                <option value="Pencabutan Gigi">Pencabutan Gigi</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pilih Dokter</label>
            <select id="dokter-select" required>
                <option value="">-- Pilih Dokter --</option>
                <option value="drg. Ahmad">drg. Ahmad</option>
                <option value="drg. Siti">drg. Siti</option>
            </select>
        </div>
        <div class="form-group">
            <label>Tanggal Reservasi</label>
            <input type="date" id="tanggal" required>
        </div>
        <div class="form-group">
            <label>Shift / Jam</label>
            <input type="text" id="jam" required placeholder="Contoh: 09:00 - 10:00 WITA">
        </div>
        <button type="submit">Kirim & Kirim WhatsApp</button>
    </form>
</div>

<script src="<?php echo e(asset('script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\ASUS\Herd\odhenta-smart\resources\views/welcome.blade.php ENDPATH**/ ?>