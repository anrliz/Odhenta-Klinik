document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // Mengambil data dari form
  const nama = document.getElementById('nama').value;
  const nohp = document.getElementById('nohp').value;
  const layanan = document.getElementById('layanan-select').value;
  const dokter = document.getElementById('dokter-select').value;
  const tanggal = document.getElementById('tanggal').value;
  const jam = document.getElementById('jam').value;

  // Simpan booking ke database MySQL
  // (tanpa await agar popup WhatsApp tidak diblokir browser)
  fetch('/booking', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
      },
      keepalive: true,
      body: JSON.stringify({ nama, nohp, layanan, dokter, tanggal, jam })
    }).catch(err => console.error('Gagal simpan booking:', err));

  // Nomor WhatsApp resmi klinik (082259824496)
  const targetPhone = "6282259824496"; 
  
  // Format pesan WhatsApp
  const message = `Halo ODHENTA SMART / CLINIC,\n` +
                  `Saya ingin melakukan booking jadwal konsultasi/perawatan:\n\n` +
                  `👤 *Nama Pasien:* ${nama}\n` +
                  `📱 *No. HP/WA:* ${nohp}\n` +
                  `🦷 *Layanan:* ${layanan}\n` +
                  `👨‍⚕️ *Dokter:* ${dokter}\n` +
                  `📅 *Tanggal:* ${tanggal}\n` +
                  `⏰ *Shift/Jam:* ${jam}\n\n` +
                  `Mohon konfirmasi ketersediaan jadwal. Terima kasih!`;

  const encodedMessage = encodeURIComponent(message);
  const whatsappURL = `https://wa.me/${targetPhone}?text=${encodedMessage}`;

  // Mengarahkan langsung ke WA
  window.open(whatsappURL, '_blank');
});