<?php

namespace Database\Seeders;

use App\Models\Patient;
use Illuminate\Database\Seeder;

class PatientSeeder extends Seeder
{
    public function run(): void
    {
        $p = Patient::create([
            'id_pasien'      => 'RM-2026-001',
            'nohp'           => '082259824496',
            'nama'           => 'Ahmad Subagja',
            'jenis_kelamin'  => 'Laki-laki',
            'tanggal_lahir'  => '1995-05-14',
            'golongan_darah' => 'O',
        ]);

        $p->records()->create([
            'no_rekam_medis'  => 'REC-2026-0910',
            'tanggal_periksa' => '2026-09-10',
            'dokter'          => 'drg. Rahman',
            'layanan'         => 'Scalling (Pembersihan Karang)',
            'keluhan_utama'   => "Gigi terasa ngilu saat minum air dingin dan karang gigi menumpuk di area gigi bawah.",
            'diagnosa_klinis' => "Gingivitis kronis lokal ec kalkulus supra & subgingiva.",
            'tindakan_medis'  => "Ultrasonic Scaling RA/RB, Polishing dengan paste prophy, dan topical application fluor.",
            'resep_obat'      => "Chlorhexidine Gluconate 0.2% mouthwash 2x sehari (kumur) selama 5 hari.",
            'catatan_dokter'  => "Rutin sikat gigi dengan teknik Roll 2x sehari. Kontrol ulang scalling 6 bulan mendatang.",
        ]);

        $p->records()->create([
            'no_rekam_medis'  => 'REC-2026-0415',
            'tanggal_periksa' => '2026-04-15',
            'dokter'          => 'drg. Rahman',
            'layanan'         => 'Penambalan Gigi Belakang',
            'keluhan_utama'   => "Gigi geraham kiri bawah berlubang, sering tersangkut sisa makanan.",
            'diagnosa_klinis' => "Karies dentin media pada gigi 36 (Molar 1 Kiri Bawah).",
            'tindakan_medis'  => "Ekskavasi jaringan karies, preparasi kavitas, penambalan komposit resin light-cured.",
            'resep_obat'      => "Mefenamic Acid 500mg (jika timbul rasa ngilu pasca penambalan).",
            'catatan_dokter'  => "Hindari mengunyah makanan bertekstur sangat keras pada area kiri selama 24 jam pertama.",
        ]);
    }
}