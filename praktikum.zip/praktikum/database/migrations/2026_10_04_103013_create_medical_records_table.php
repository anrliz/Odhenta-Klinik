<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('medical_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained()->cascadeOnDelete();
            $table->string('no_rekam_medis')->unique();   // REC-2026-0910
            $table->date('tanggal_periksa');
            $table->string('dokter');
            $table->string('layanan');
            $table->text('keluhan_utama');
            $table->text('diagnosa_klinis');
            $table->text('tindakan_medis');
            $table->text('resep_obat')->nullable();
            $table->text('catatan_dokter')->nullable();
            $table->timestamps();
            });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('medical_records');
    }
};
