<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ODHENTA SMART - Klinik Gigi & Mulut</title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <style>
    /* Styling Tambahan Khusus Entitas Rekam Medis Pasien */
    .search-box-card {
      background: #ffffff;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
      max-width: 650px;
      margin: 0 auto 2rem auto;
    }

    .patient-profile-card {
      background: #ffffff;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      margin-bottom: 2rem;
      border-left: 6px solid #0056b3;
    }

    .patient-profile-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
      border-bottom: 1px solid #eee;
      padding-bottom: 0.8rem;
      margin-bottom: 1rem;
    }

    .patient-profile-header h3 {
      margin: 0;
      color: #0056b3;
      font-size: 1.3rem;
    }

    .patient-id-badge {
      background: #e6f0fa;
      color: #0056b3;
      padding: 4px 12px;
      border-radius: 20px;
      font-weight: bold;
      font-size: 0.85rem;
    }

    .patient-info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 10px;
      font-size: 0.95rem;
      color: #444;
    }

    .medical-record-card {
      background: #ffffff;
      border: 1px solid #e1e8ed;
      border-radius: 12px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .medical-record-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .record-header-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      background: #f8fafc;
      padding: 10px 15px;
      border-radius: 8px;
      margin-bottom: 1rem;
    }

    .record-date-badge {
      font-weight: bold;
      color: #0056b3;
    }

    .record-doctor-badge {
      font-size: 0.9rem;
      color: #555;
    }

    .record-attributes-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 15px;
    }

    .attribute-group {
      background: #fdfdfd;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #f0f0f0;
    }

    .attribute-group label {
      display: block;
      font-size: 0.8rem;
      font-weight: bold;
      text-transform: uppercase;
      color: #0056b3;
      margin-bottom: 4px;
      letter-spacing: 0.5px;
    }

    .attribute-group p {
      margin: 0;
      font-size: 0.95rem;
      color: #222;
      line-height: 1.4;
    }

    .no-data-alert {
      text-align: center;
      padding: 2.5rem;
      background: #fff8e6;
      color: #8a6d3b;
      border-radius: 12px;
      border: 1px solid #faebcc;
    }
  </style>
</head>
<body>

  <!-- NAVBAR -->
  <header class="navbar">
    <div class="logo">
      <img src="<?php echo e(asset('images/logo.jpeg')); ?>" alt="ODHENTA SMART">
    </div>
    <nav>
      <ul class="nav-links">
        <li><a href="#home">HOME</a></li>
        <li><a href="#tentang">TENTANG</a></li>
        <li><a href="#layanan">LAYANAN & HARGA</a></li>
        <li><a href="#dokter">DOKTER</a></li>
        <li><a href="#jadwal">JADWAL</a></li>
        <li><a href="#kontak">KONTAK</a></li>
        <li><a href="#rekam-medis">REKAM MEDIS</a></li>
        <li><a href="#booking" class="btn-booking-nav">🔵 BOOKING</a></li>
      </ul>
    </nav>
  </header>

  <!-- 1. HOME -->
  <section id="home" class="hero">
    <div class="hero-content">
      <h1>ODHENTA SMART</h1>
      <p class="slogan">“Kesehatan gigi dan mulut Anda adalah prioritas kami” 💙</p>
      <p class="description">Pelayanan kesehatan gigi profesional dan terpercaya bersama drg. Rahman. <em>Healthy Smile, Happy Life!</em></p>
      <a href="#booking" class="btn-primary">Booking Sekarang</a>
    </div>
    <div class="hero-image">
      <img src="<?php echo e(asset('images/logo.jpeg')); ?>" alt="ODHENTA CLINIC" style="max-width: 100%; height: auto; border-radius: 12px;">
    </div>
  </section>

  <!-- 2. TENTANG -->
  <section id="tentang" class="section">
    <h2 class="section-title">TENTANG KAMI</h2>
    <div class="about-grid">
      <div class="card">
        <h3>Profil ODHENTA SMART</h3>
        <p>Pusat perawatan kesehatan gigi terpercaya mitra ODHENTA CLINIC yang hadir memberikan kenyamanan dan estetika senyum terbaik bagi Anda dan keluarga.</p>
      </div>
      <div class="card">
        <h3>Visi & Misi</h3>
        <p><strong>Visi:</strong> Menjadi klinik gigi pilihan utama dengan pelayanan berkualitas tinggi dan mengutamakan kenyamanan pasien.</p>
        <p><strong>Misi:</strong> Memberikan edukasi dan tindakan medis gigi yang aman, akurat, serta ramah untuk semua usia.</p>
      </div>
      <div class="card">
        <h3>Keunggulan Klinik</h3>
        <ul>
          <li>Penanganan langsung oleh drg. Rahman</li>
          <li>Peralatan modern & terjamin steril</li>
          <li>Pelayanan ramah & transparan</li>
          <li>Harga terjangkau & jadwal fleksibel</li>
        </ul>
      </div>
    </div>
  </section>

  <!-- 3. LAYANAN & PRICE LIST -->
  <section id="layanan" class="section bg-light">
    <h2 class="section-title">PRICE LIST & LAYANAN</h2>
    <div class="services-grid">
      
      <div class="service-category">
        <h3><i class="fa-solid fa-teeth-open"></i> Orthodontic Treatment</h3>
        <ul>
          <li><span>Metal Orthodontic</span> <strong>Rp 3.500.000</strong></li>
          <li><span>Metal American Orthodontic</span> <strong>Rp 6.000.000</strong></li>
          <li><span>Ceramic Orthodontic</span> <strong>Rp 10.000.000</strong></li>
          <li><span>Sapphire Orthodontic</span> <strong>Rp 12.000.000</strong></li>
          <li><span>Metal Damon Self-Ligating System</span> <strong>Rp 12.000.000</strong></li>
          <li><span>Kontrol Ortho</span> <strong>Rp 100.000</strong></li>
          <li><span>Kontrol Ortho Luar</span> <strong>Rp 200.000</strong></li>
          <li><span>Bracket Lepas</span> <strong>Rp 50.000</strong></li>
          <li><span>Lepas Ortho</span> <strong>Rp 500.000</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-sparkles"></i> Pembersihan Karang Gigi</h3>
        <ul>
          <li><span>Scalling (Pembersihan Karang)</span> <strong>Rp 200rb - 350rb</strong></li>
          <li><span>Dental Spa (Scalling + Polishing + Brushing)</span> <strong>Rp 350rb - 500rb</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-child"></i> Perawatan Gigi Anak</h3>
        <ul>
          <li><span>Penambalan Gigi Anak</span> <strong>Rp 100rb - 300rb</strong></li>
          <li><span>Pencabutan Gigi Anak</span> <strong>Rp 100rb - 300rb</strong></li>
          <li><span>Scalling Anak</span> <strong>Rp 200rb - 400rb</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-tooth"></i> Prostodontic (Gigi Palsu)</h3>
        <ul>
          <li><span>Crown / Veneer Indirect</span> <strong>Rp 2,5jt - 6jt</strong></li>
          <li><span>Gigi Tiruan Lepasan (Satuan)</span> <strong>Rp 300rb - 500rb</strong></li>
          <li><span>Gigi Tiruan Lepasan (Full Denture)</span> <strong>Rp 7.000.000</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-wand-magic-sparkles"></i> Bleaching Treatment</h3>
        <ul>
          <li><span>Bleaching Whitening</span> <strong>Rp 1.500.000</strong></li>
          <li><span>Bleaching Glow Whitening</span> <strong>Rp 2.000.000</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-syringe"></i> Pencabutan Gigi</h3>
        <ul>
          <li><span>Pencabutan Gigi</span> <strong>Rp 100rb - 350rb</strong></li>
          <li><span>Pencabutan Gigi Komplikasi</span> <strong>Rp 350rb - 500rb</strong></li>
          <li><span>Pencabutan Gigi Impaksi Atas</span> <strong>Rp 500rb - 750rb</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-notes-medical"></i> Perawatan Saluran Akar</h3>
        <ul>
          <li><span>PSA Gigi Depan (Incisivus & Caninus)</span> <strong>Rp 650.000</strong></li>
          <li><span>PSA Gigi Geraham Kecil (Premolar)</span> <strong>Rp 650rb - 1jt</strong></li>
          <li><span>Re-Treatment PSA</span> <strong>Rp 1.500.000</strong></li>
        </ul>
      </div>

      <div class="service-category">
        <h3><i class="fa-solid fa-fill-drip"></i> Penambalan Gigi</h3>
        <ul>
          <li><span>Penambalan Gigi Depan</span> <strong>Rp 300rb - 500rb</strong></li>
          <li><span>Penambalan Gigi Belakang</span> <strong>Rp 200rb - 350rb</strong></li>
          <li><span>Pulp Capping</span> <strong>Rp 350.000</strong></li>
          <li><span>Tambalan Sementara</span> <strong>Rp 150.000</strong></li>
        </ul>
      </div>

    </div>
  </section>

  <!-- 4. DOKTER -->
  <section id="dokter" class="section">
    <h2 class="section-title">DOKTER KAMI</h2>
    <div class="doctor-single-container">
      <div class="doctor-card single-doctor">
        <div class="doctor-img"><i class="fa-solid fa-user-doctor"></i></div>
        <h3>drg. Rahman</h3>
        <p class="spec">Dokter Gigi Utama</p>
        <p class="exp">Berpengalaman luas dalam penanganan perawatan Orthodontic, Pencabutan Komplikasi, Restorasi Estetika Gigi, serta Perawatan Gigi Anak.</p>
      </div>
    </div>
  </section>

  <!-- 5. JADWAL OPERASIONAL -->
  <section id="jadwal" class="section bg-light">
    <h2 class="section-title">JAM OPERASIONAL & JADWAL</h2>
    <div class="schedule-info">
      <p class="days-badge"><i class="fa-regular fa-calendar-days"></i> SENIN - MINGGU</p>
      <div class="shifts">
        <div class="shift-card">
          <i class="fa-solid fa-sun icon-sun"></i>
          <div>
            <h4>SHIFT 1</h4>
            <p>08.00 - 11.00 WITA</p>
          </div>
        </div>
        <div class="shift-card">
          <i class="fa-solid fa-moon icon-moon"></i>
          <div>
            <h4>SHIFT 2</h4>
            <p>14.00 - 21.00 WITA</p>
          </div>
        </div>
      </div>
    </div>

    <div class="table-container" style="margin-top: 2rem;">
      <table>
        <thead>
          <tr>
            <th>Nama Dokter</th>
            <th>Hari Praktik</th>
            <th>Jam / Shift</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>drg. Rahman</td>
            <td>Senin - Minggu</td>
            <td>Shift 1 & Shift 2</td>
            <td><span class="badge available">Tersedia</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <!-- 6. KONTAK -->
  <section id="kontak" class="section">
    <h2 class="section-title">KONTAK & LOKASI</h2>
    <div class="contact-grid">
      <div class="contact-info">
        <div class="contact-item">
          <i class="fa-solid fa-location-dot"></i>
          <p><strong>Alamat:</strong> Jln. Kompleks Pasar Guali</p>
        </div>
        <div class="contact-item">
          <i class="fa-brands fa-whatsapp"></i>
          <p><strong>WhatsApp:</strong> 082259824496</p>
        </div>
        <div class="contact-item">
          <i class="fa-brands fa-instagram"></i>
          <p><strong>Instagram:</strong> @Odhenta_clinic</p>
        </div>
        <div class="contact-item">
          <i class="fa-brands fa-tiktok"></i>
          <p><strong>TikTok:</strong> @Odhenta_clinic</p>
        </div>
      </div>
      <div class="map-placeholder">
        <i class="fa-solid fa-map-location-dot"></i>
        <span>Peta Lokasi: Jln. Kompleks Pasar Guali</span>
      </div>
    </div>
  </section>

  <!-- 7. REKAM MEDIS PASIEN (ENTITAS BARU) -->
  <section id="rekam-medis" class="section bg-light">
    <h2 class="section-title">REKAM MEDIS PASIEN</h2>
    
    <div class="search-box-card">
      <p style="text-align: center; margin-bottom: 1.2rem; color: #555;">
        Masukkan <strong>Nomor WhatsApp</strong> atau <strong>ID Pasien / Rekam Medis</strong> Anda untuk mengakses riwayat pemeriksaan klinis.
      </p>
      <form id="searchMedicalRecordForm" style="display: flex; gap: 10px; flex-wrap: wrap;">
        <input type="text" id="searchKeyword" placeholder="Contoh: 082259824496 atau RM-2026-001" required style="flex: 1; min-width: 240px; padding: 12px; border: 1px solid #ccc; border-radius: 8px;">
        <button type="submit" class="btn-primary" style="padding: 12px 24px;">
          <i class="fa-solid fa-magnifying-glass"></i> Cari Rekam Medis
        </button>
      </form>
    </div>

    <!-- Container Hasil Pencarian Rekam Medis -->
    <div id="medicalRecordResult" style="max-width: 850px; margin: 0 auto; display: none;">
      <!-- Content dirender secara dinamis melalui JavaScript -->
    </div>
  </section>

  <!-- 8. BOOKING -->
  <section id="booking" class="section">
    <h2 class="section-title">FORMULIR BOOKING ONLINE</h2>
    <form class="booking-form" id="bookingForm">
      <div class="form-group">
        <label for="nama">Nama Pasien</label>
        <input type="text" id="nama" required placeholder="Masukkan nama lengkap Anda">
      </div>
      
      <div class="form-group">
        <label for="nohp">Nomor HP / WhatsApp</label>
        <input type="tel" id="nohp" required placeholder="Contoh: 082259824496">
      </div>

      <div class="form-group">
        <label for="layanan-select">Pilih Perawatan / Layanan</label>
        <select id="layanan-select" required>
          <option value="">-- Pilih Layanan --</option>
          <optgroup label="Orthodontic Treatment">
            <option value="Metal Orthodontic">Metal Orthodontic (Rp 3.5jt)</option>
            <option value="Metal American Orthodontic">Metal American Orthodontic (Rp 6jt)</option>
            <option value="Ceramic Orthodontic">Ceramic Orthodontic (Rp 10jt)</option>
            <option value="Sapphire Orthodontic">Sapphire Orthodontic (Rp 12jt)</option>
            <option value="Metal Damon Self-Ligating System">Metal Damon Self-Ligating System (Rp 12jt)</option>
            <option value="Kontrol Ortho">Kontrol Ortho (Rp 100rb)</option>
            <option value="Kontrol Ortho Luar">Kontrol Ortho Luar (Rp 200rb)</option>
            <option value="Bracket Lepas">Bracket Lepas (Rp 50rb)</option>
            <option value="Lepas Ortho">Lepas Ortho (Rp 500rb)</option>
          </optgroup>
          <optgroup label="Pembersihan Karang Gigi">
            <option value="Scalling">Scalling (Rp 200rb - 350rb)</option>
            <option value="Dental Spa">Dental Spa (Rp 350rb - 500rb)</option>
          </optgroup>
          <optgroup label="Bleaching Treatment">
            <option value="Bleaching Whitening">Bleaching Whitening (Rp 1.5jt)</option>
            <option value="Bleaching Glow Whitening">Bleaching Glow Whitening (Rp 2jt)</option>
          </optgroup>
          <optgroup label="Perawatan Gigi Anak">
            <option value="Penambalan Gigi Anak">Penambalan Gigi Anak (Rp 100rb - 300rb)</option>
            <option value="Pencabutan Gigi Anak">Pencabutan Gigi Anak (Rp 100rb - 300rb)</option>
            <option value="Scalling Anak">Scalling Anak (Rp 200rb - 400rb)</option>
          </optgroup>
          <optgroup label="Pencabutan Gigi">
            <option value="Pencabutan Gigi">Pencabutan Gigi (Rp 100rb - 350rb)</option>
            <option value="Pencabutan Gigi Komplikasi">Pencabutan Gigi Komplikasi (Rp 350rb - 500rb)</option>
            <option value="Pencabutan Gigi Impaksi Atas">Pencabutan Gigi Impaksi Atas (Rp 500rb - 750rb)</option>
          </optgroup>
          <optgroup label="Penambalan & Restorasi">
            <option value="Penambalan Gigi Depan">Penambalan Gigi Depan (Rp 300rb - 500rb)</option>
            <option value="Penambalan Gigi Belakang">Penambalan Gigi Belakang (Rp 200rb - 350rb)</option>
            <option value="Pulp Capping">Pulp Capping (Rp 350rb)</option>
            <option value="Tambalan Sementara">Tambalan Sementara (Rp 150rb)</option>
          </optgroup>
          <optgroup label="Perawatan Saluran Akar (PSA)">
            <option value="PSA Gigi Depan">PSA Gigi Depan (Rp 650rb)</option>
            <option value="PSA Gigi Geraham Kecil">PSA Gigi Geraham Kecil (Rp 650rb - 1jt)</option>
            <option value="Re-Treatment PSA">Re-Treatment PSA (Rp 1.5jt)</option>
          </optgroup>
          <optgroup label="Prostodontic (Gigi Palsu)">
            <option value="Crown/Veneer Indirect">Crown / Veneer Indirect (Rp 2.5jt - 6jt)</option>
            <option value="Gigi Tiruan Lepasan Satuan">Gigi Tiruan Lepasan Satuan (Rp 300rb - 500rb)</option>
            <option value="Gigi Tiruan Lepasan Full Denture">Gigi Tiruan Lepasan Full Denture (Rp 7jt)</option>
          </optgroup>
        </select>
      </div>

      <div class="form-group">
        <label for="dokter-select">Dokter yang Menangani</label>
        <select id="dokter-select" required>
          <option value="drg. Rahman" selected>drg. Rahman</option>
        </select>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="tanggal">Pilih Tanggal</label>
          <input type="date" id="tanggal" required>
        </div>

        <div class="form-group">
          <label for="jam">Pilih Jam / Shift</label>
          <select id="jam" required>
            <option value="">-- Pilih Shift --</option>
            <option value="Shift 1 (08.00-11.00)">Shift 1 (08.00 - 11.00 WITA)</option>
            <option value="Shift 2 (14.00-21.00)">Shift 2 (14.00 - 21.00 WITA)</option>
          </select>
        </div>
      </div>

      <button type="submit" class="btn-submit"><i class="fa-brands fa-whatsapp"></i> Kirim Booking via WhatsApp</button>
    </form>
  </section>

  <footer>
    <p>&copy; 2026 ODHENTA SMART. All Rights Reserved. Mitra ODHENTA CLINIC.</p>
  </footer>

  <script src="<?php echo e(asset('js/script.js')); ?>"></script>
  
  <script>
    // LOGIKA PENCARIAN REKAM MEDIS (DARI DATABASE MYSQL)

    document.addEventListener("DOMContentLoaded", () => {
      const searchForm = document.getElementById("searchMedicalRecordForm");
      const searchInput = document.getElementById("searchKeyword");
      const resultBox = document.getElementById("medicalRecordResult");

      if (searchForm) {
        searchForm.addEventListener("submit", async (e) => {
          e.preventDefault();
          const keyword = searchInput.value.trim();

          let patient = null;
          try {
            const res = await fetch('/rekam-medis/cari', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
              },
              body: JSON.stringify({ keyword })
            });
            const json = await res.json();
            patient = json.found ? json.patient : null;
          } catch (err) {
            console.error('Gagal mengambil rekam medis:', err);
          }

          resultBox.style.display = "block";

          if (patient) {
            let htmlContent = `
              <div class="patient-profile-card">
                <div class="patient-profile-header">
                  <h3><i class="fa-solid fa-address-card"></i> ${patient.namaPasien}</h3>
                  <span class="patient-id-badge">ID: ${patient.idPasien}</span>
                </div>
                <div class="patient-info-grid">
                  <div><strong>No. WhatsApp:</strong> ${patient.nohp}</div>
                  <div><strong>Jenis Kelamin:</strong> ${patient.jenisKelamin}</div>
                  <div><strong>Tanggal Lahir:</strong> ${patient.tanggalLahir}</div>
                  <div><strong>Gol. Darah:</strong> ${patient.golonganDarah}</div>
                </div>
              </div>

              <h3 style="margin-bottom: 1rem; color: #0056b3;"><i class="fa-solid fa-notes-medical"></i> Riwayat Pemeriksaan & Tindakan</h3>
            `;

            patient.riwayatPemeriksaan.forEach(rec => {
              htmlContent += `
                <div class="medical-record-card">
                  <div class="record-header-meta">
                    <span class="record-date-badge"><i class="fa-regular fa-calendar-check"></i> ${rec.tanggalPeriksa}</span>
                    <span class="record-doctor-badge"><i class="fa-solid fa-user-doctor"></i> ${rec.dokterPenanggungJawab}</span>
                    <span style="font-size:0.8rem; color:#888;">No. Reg: ${rec.noRekamMedis}</span>
                  </div>

                  <div class="record-attributes-grid">
                    <div class="attribute-group" style="grid-column: 1 / -1; background: #eef6ff;">
                      <label><i class="fa-solid fa-tooth"></i> Perawatan / Layanan</label>
                      <p><strong>${rec.layanan}</strong></p>
                    </div>

                    <div class="attribute-group">
                      <label><i class="fa-solid fa-comment-dots"></i> Keluhan Utama</label>
                      <p>${rec.keluhanUtama}</p>
                    </div>

                    <div class="attribute-group">
                      <label><i class="fa-solid fa-stethoscope"></i> Diagnosa Klinis</label>
                      <p>${rec.diagnosaKlinis}</p>
                    </div>

                    <div class="attribute-group" style="grid-column: 1 / -1;">
                      <label><i class="fa-solid fa-syringe"></i> Tindakan Medis</label>
                      <p>${rec.tindakanMedis}</p>
                    </div>

                    <div class="attribute-group">
                      <label><i class="fa-solid fa-pills"></i> Resep Obat</label>
                      <p>${rec.resepObat}</p>
                    </div>

                    <div class="attribute-group">
                      <label><i class="fa-solid fa-user-nurse"></i> Catatan & Anjuran Dokter</label>
                      <p><em>${rec.catatanDokter}</em></p>
                    </div>
                  </div>
                </div>
              `;
            });

            resultBox.innerHTML = htmlContent;
          } else {
            resultBox.innerHTML = `
              <div class="no-data-alert">
                <i class="fa-solid fa-triangle-exclamation fa-2x" style="margin-bottom: 0.8rem;"></i>
                <h4 style="margin: 0 0 0.5rem 0;">Data Rekam Medis Tidak Ditemukan</h4>
                <p style="margin: 0;">Pastikan Nomor WhatsApp atau ID Pasien yang Anda masukkan benar sesuai data pendaftaran klinik.</p>
              </div>
            `;
          }
        });
      }
    });
  </script>
</body>
</html><?php /**PATH C:\Users\ASUS\Herd\praktikum\resources\views/home.blade.php ENDPATH**/ ?>