<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    protected $fillable = ['id_pasien','nohp','nama','jenis_kelamin','tanggal_lahir','golongan_darah'];
    protected $casts = ['tanggal_lahir' => 'date'];
    
    public function records() { return $this->hasMany(MedicalRecord::class)->orderByDesc('tanggal_periksa'); }
}
