<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalRecord extends Model
{
    protected $fillable = ['patient_id','no_rekam_medis','tanggal_periksa','dokter','layanan','keluhan_utama','diagnosa_klinis','tindakan_medis','resep_obat','catatan_dokter'];
    protected $casts = ['tanggal_periksa' => 'date'];
}
