<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    protected $fillable = ['nama', 'nohp', 'layanan', 'dokter', 'tanggal', 'jam'];
}
