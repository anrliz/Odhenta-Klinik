<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use Illuminate\Http\Request;

class RekamMedisController extends Controller
{
    public function cari(Request $request)
    {
        $request->validate(['keyword' => 'required|string|max:50']);
        $kw = trim($request->keyword);

        $p = Patient::with('records')
            ->where('nohp', $kw)
            ->orWhere('id_pasien', $kw)
            ->first();

        if (!$p) {
            return response()->json(['found' => false]);
        }

        return response()->json([
            'found' => true,
            'patient' => [
                'idPasien' => $p->id_pasien,
                'nohp' => $p->nohp,
                'namaPasien' => $p->nama,
                'jenisKelamin' => $p->jenis_kelamin,
                'tanggalLahir' => $p->tanggal_lahir->translatedFormat('d F Y'),
                'golonganDarah' => $p->golongan_darah,
                'riwayatPemeriksaan' => $p->records->map(fn ($r) => [
                    'noRekamMedis' => $r->no_rekam_medis,
                    'tanggalPeriksa' => $r->tanggal_periksa->translatedFormat('d F Y'),
                    'dokterPenanggungJawab' => $r->dokter,
                    'layanan' => $r->layanan,
                    'keluhanUtama' => $r->keluhan_utama,
                    'diagnosaKlinis' => $r->diagnosa_klinis,
                    'tindakanMedis' => $r->tindakan_medis,
                    'resepObat' => $r->resep_obat,
                    'catatanDokter' => $r->catatan_dokter,
                ]),
            ],
        ]);
    }
}