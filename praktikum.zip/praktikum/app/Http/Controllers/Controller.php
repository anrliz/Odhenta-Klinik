<?php

namespace App\Http\Controllers;

abstract class Controller
{
    <?php

namespace App\Http\Controllers;

use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'nama'    => 'required|string|max:100',
            'nohp'    => 'required|string|max:20',
            'layanan' => 'required|string|max:100',
            'dokter'  => 'required|string|max:100',
            'tanggal' => 'required|date',
            'jam'     => 'required|string|max:50',
        ]);

        Booking::create($data);

        return response()->json(['success' => true]);
    }
}
}
